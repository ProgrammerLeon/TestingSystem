create procedure storeAndCheck @StuID varchar(25),@PaperID varchar(25),@QueID varchar(25),@UserAns varchar(25) as
begin
	declare @CorrectAns nchar(1)
	set @CorrectAns = (select question_answer from [QuestionInfo] where [question_id] = @QueID)
	print @CorrectAns
	print @UserAns
	insert into TestResultInfo values(@StuID,@PaperID,@QueID,@UserAns,IIF(@UserAns=@CorrectAns,'Y','N'))
end
GO

