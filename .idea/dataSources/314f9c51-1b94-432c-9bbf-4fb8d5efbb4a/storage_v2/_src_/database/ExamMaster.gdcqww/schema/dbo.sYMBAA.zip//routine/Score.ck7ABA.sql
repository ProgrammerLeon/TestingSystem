CREATE procedure Score @StuID varchar(25),@PaperID varchar(25) as
begin
	declare @num int = (select count(*) from QuestionInfo where paper_id = @PaperID)
	declare @cornum int = (select count(*) from TestResultInfo where test_Result = 'Y' and paper_id  = @PaperID)
	insert into ExamResultInfo values(@StuID,@PaperID,@cornum*1.0/@num*100,getdate())
end

GO

