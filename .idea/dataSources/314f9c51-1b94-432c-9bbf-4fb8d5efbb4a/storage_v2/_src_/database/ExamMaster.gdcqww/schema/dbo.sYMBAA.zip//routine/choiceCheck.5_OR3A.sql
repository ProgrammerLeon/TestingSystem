create procedure choiceCheck @StuID varchar(25),@PaperID varchar(25) as
begin
	if EXISTS(select * from ExamResultInfo where student_id = @StuID and paper_id = @PaperID)
	begin
		raiserror('ERROR',12,1)
	end
end
GO

